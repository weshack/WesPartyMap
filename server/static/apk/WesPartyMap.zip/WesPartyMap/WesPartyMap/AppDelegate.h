//
//  AppDelegate.h
//  WesPartyMap
//
//  Created by Sam on 9/6/13.
//  Copyright (c) 2013 weshack. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) UIBackgroundTaskIdentifier bgTask;

@end
