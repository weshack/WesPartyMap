//
//  ViewController.h
//  WesPartyMap
//
//  Created by Sam on 9/6/13.
//  Copyright (c) 2013 weshack. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *address;

@end
